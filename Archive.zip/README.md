# Instalación

- python 2.x
- Django 1.10

## Ejecución local

`python manage.py migrate`
`python manage.py createsuperuser`
`python manage.py runserver`

El servidor estará corriendo en http://localhost:8000
